"use strict"
var optionSettings = {
    layout:"wide",
    background:"white",
    color:"pink",
    header:"fixed",
    font:"opensans",
    textDirection:"ltr",
    radius:"sixradius",
    showSettings:"show",
};
new antlerSettings(optionSettings);